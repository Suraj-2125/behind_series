# HTML Table & CSS Table

A Pen created on CodePen.io. Original URL: [https://codepen.io/ahmadawais/pen/WbvzQd](https://codepen.io/ahmadawais/pen/WbvzQd).

CSS Tables are cool. Use CSS Tables for layouts when you need easy vertical alignment, CSS based fixed footers with dynamic heights, and stack ordering.
